/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package compres;

/**
 *
 * @author DELY
 */
public class formater {
 
    
    public static void main(String[] args)
    {
        int i=8;
        java.text.DecimalFormat nft = new
        java.text.DecimalFormat("#00.###");
        nft.setDecimalSeparatorAlwaysShown(false);
        String hasil = nft.format(i);
        System.out.println(hasil);
        
    }
}
