/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package compres;

/**
 *
 * @author DELY
 */


public class XOREncryption {
    
    private static final boolean encrypt = true;
    private static final boolean decrypt = false;

    private static String encryptDecrypt(String input, boolean is_encrypt) {
		
                String msg ="",hasil="";
                if(is_encrypt){
                    msg = Shift(input,3,is_encrypt);
                }else{
                    msg = input;
                }
                char[] key = {'M', 'S', 'G'};
		StringBuilder output = new StringBuilder();
		for(int i = 0; i < msg.length(); i++) {
			output.append((char) (msg.charAt(i) ^ key[i % key.length]));
		}
                
                if(!is_encrypt){
                    hasil = Shift(output.toString(),3,is_encrypt);
                }else{
                    hasil = output.toString();
                }
		return hasil;
	}
	
	public static void main(String[] args) {
		
                String pesan = "nama saya dely Teja Mukti";
                String enkrip = XOREncryption.encryptDecrypt(pesan,encrypt);
                System.out.println(enkrip);
                String dekrip = XOREncryption.encryptDecrypt(enkrip,decrypt);
                System.out.println(dekrip);
	}
        public static String Shift(String msg, int shift, boolean is_encrypt){
            String s = "";
            int len = msg.length();
            if(is_encrypt){
                for(int x = 0; x < len; x++){
                char c = (char)(msg.charAt(x) + shift);    
                    s += (char)(msg.charAt(x) + shift);
                }
            }else{
                
                for(int x = 0; x < len; x++){
                char c = (char)(msg.charAt(x) - shift);    
                    s += (char)(msg.charAt(x) - shift);
                }
            }
            
            return s;
        }
}
